# Biblioteca VarSpeedServo

Utilização com exemplo joystick e suporte Pan/Tilt do blog FILIPEFLOP

https://www.makerhero.com/blog/controlando-micro-servo-9g-usando-joystick/
